--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 15.0
-- Dumped by pg_dump version 15.0

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE hibernaterelations;
--
-- Name: hibernaterelations; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE hibernaterelations WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'Turkish_Turkey.1254';


ALTER DATABASE hibernaterelations OWNER TO postgres;

\connect hibernaterelations

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: roles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.roles (
    id bigint NOT NULL,
    created_on timestamp(6) without time zone,
    description character varying(255),
    role_name character varying(255)
);


ALTER TABLE public.roles OWNER TO postgres;

--
-- Name: roles_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.roles_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.roles_id_seq OWNER TO postgres;

--
-- Name: roles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.roles_id_seq OWNED BY public.roles.id;


--
-- Name: roles_rules; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.roles_rules (
    role_id bigint NOT NULL,
    rule_id bigint NOT NULL
);


ALTER TABLE public.roles_rules OWNER TO postgres;

--
-- Name: rules; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.rules (
    id bigint NOT NULL,
    created_on timestamp(6) without time zone,
    description character varying(255),
    rule_name character varying(255)
);


ALTER TABLE public.rules OWNER TO postgres;

--
-- Name: rules_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.rules_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.rules_id_seq OWNER TO postgres;

--
-- Name: rules_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.rules_id_seq OWNED BY public.rules.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id bigint NOT NULL,
    created_on timestamp(6) without time zone,
    email character varying(255),
    password character varying(255),
    role_id bigint NOT NULL,
    user_detail_id bigint NOT NULL
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: users_details; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users_details (
    id bigint NOT NULL,
    biography character varying(255),
    first_name character varying(255),
    gender character varying(255),
    last_name character varying(255),
    picture oid
);


ALTER TABLE public.users_details OWNER TO postgres;

--
-- Name: users_details_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.users_details_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_details_id_seq OWNER TO postgres;

--
-- Name: users_details_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.users_details_id_seq OWNED BY public.users_details.id;


--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_id_seq OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: roles id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles ALTER COLUMN id SET DEFAULT nextval('public.roles_id_seq'::regclass);


--
-- Name: rules id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rules ALTER COLUMN id SET DEFAULT nextval('public.rules_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Name: users_details id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users_details ALTER COLUMN id SET DEFAULT nextval('public.users_details_id_seq'::regclass);


--
-- Name: 23408; Type: BLOB; Schema: -; Owner: postgres
--

SELECT pg_catalog.lo_create('23408');


ALTER LARGE OBJECT 23408 OWNER TO postgres;

--
-- Name: 23470; Type: BLOB; Schema: -; Owner: postgres
--

SELECT pg_catalog.lo_create('23470');


ALTER LARGE OBJECT 23470 OWNER TO postgres;

--
-- Name: 23533; Type: BLOB; Schema: -; Owner: postgres
--

SELECT pg_catalog.lo_create('23533');


ALTER LARGE OBJECT 23533 OWNER TO postgres;

--
-- Name: 23656; Type: BLOB; Schema: -; Owner: postgres
--

SELECT pg_catalog.lo_create('23656');


ALTER LARGE OBJECT 23656 OWNER TO postgres;

--
-- Name: 23718; Type: BLOB; Schema: -; Owner: postgres
--

SELECT pg_catalog.lo_create('23718');


ALTER LARGE OBJECT 23718 OWNER TO postgres;

--
-- Name: 23781; Type: BLOB; Schema: -; Owner: postgres
--

SELECT pg_catalog.lo_create('23781');


ALTER LARGE OBJECT 23781 OWNER TO postgres;

--
-- Name: 23843; Type: BLOB; Schema: -; Owner: postgres
--

SELECT pg_catalog.lo_create('23843');


ALTER LARGE OBJECT 23843 OWNER TO postgres;

--
-- Name: 23966; Type: BLOB; Schema: -; Owner: postgres
--

SELECT pg_catalog.lo_create('23966');


ALTER LARGE OBJECT 23966 OWNER TO postgres;

--
-- Name: 24090; Type: BLOB; Schema: -; Owner: postgres
--

SELECT pg_catalog.lo_create('24090');


ALTER LARGE OBJECT 24090 OWNER TO postgres;

--
-- Name: 24153; Type: BLOB; Schema: -; Owner: postgres
--

SELECT pg_catalog.lo_create('24153');


ALTER LARGE OBJECT 24153 OWNER TO postgres;

--
-- Name: 24154; Type: BLOB; Schema: -; Owner: postgres
--

SELECT pg_catalog.lo_create('24154');


ALTER LARGE OBJECT 24154 OWNER TO postgres;

--
-- Name: 24216; Type: BLOB; Schema: -; Owner: postgres
--

SELECT pg_catalog.lo_create('24216');


ALTER LARGE OBJECT 24216 OWNER TO postgres;

--
-- Name: 24217; Type: BLOB; Schema: -; Owner: postgres
--

SELECT pg_catalog.lo_create('24217');


ALTER LARGE OBJECT 24217 OWNER TO postgres;

--
-- Name: 24279; Type: BLOB; Schema: -; Owner: postgres
--

SELECT pg_catalog.lo_create('24279');


ALTER LARGE OBJECT 24279 OWNER TO postgres;

--
-- Name: 24280; Type: BLOB; Schema: -; Owner: postgres
--

SELECT pg_catalog.lo_create('24280');


ALTER LARGE OBJECT 24280 OWNER TO postgres;

--
-- Name: 24343; Type: BLOB; Schema: -; Owner: postgres
--

SELECT pg_catalog.lo_create('24343');


ALTER LARGE OBJECT 24343 OWNER TO postgres;

--
-- Name: 24344; Type: BLOB; Schema: -; Owner: postgres
--

SELECT pg_catalog.lo_create('24344');


ALTER LARGE OBJECT 24344 OWNER TO postgres;

--
-- Name: 24345; Type: BLOB; Schema: -; Owner: postgres
--

SELECT pg_catalog.lo_create('24345');


ALTER LARGE OBJECT 24345 OWNER TO postgres;

--
-- Name: 24407; Type: BLOB; Schema: -; Owner: postgres
--

SELECT pg_catalog.lo_create('24407');


ALTER LARGE OBJECT 24407 OWNER TO postgres;

--
-- Name: 24408; Type: BLOB; Schema: -; Owner: postgres
--

SELECT pg_catalog.lo_create('24408');


ALTER LARGE OBJECT 24408 OWNER TO postgres;

--
-- Name: 24409; Type: BLOB; Schema: -; Owner: postgres
--

SELECT pg_catalog.lo_create('24409');


ALTER LARGE OBJECT 24409 OWNER TO postgres;

--
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.roles (id, created_on, description, role_name) FROM stdin;
\.
COPY public.roles (id, created_on, description, role_name) FROM '$$PATH$$/3353.dat';

--
-- Data for Name: roles_rules; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.roles_rules (role_id, rule_id) FROM stdin;
\.
COPY public.roles_rules (role_id, rule_id) FROM '$$PATH$$/3354.dat';

--
-- Data for Name: rules; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.rules (id, created_on, description, rule_name) FROM stdin;
\.
COPY public.rules (id, created_on, description, rule_name) FROM '$$PATH$$/3356.dat';

--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, created_on, email, password, role_id, user_detail_id) FROM stdin;
\.
COPY public.users (id, created_on, email, password, role_id, user_detail_id) FROM '$$PATH$$/3358.dat';

--
-- Data for Name: users_details; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users_details (id, biography, first_name, gender, last_name, picture) FROM stdin;
\.
COPY public.users_details (id, biography, first_name, gender, last_name, picture) FROM '$$PATH$$/3360.dat';

--
-- Name: roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.roles_id_seq', 2, true);


--
-- Name: rules_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.rules_id_seq', 2, true);


--
-- Name: users_details_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_details_id_seq', 3, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_id_seq', 3, true);


--
-- Data for Name: BLOBS; Type: BLOBS; Schema: -; Owner: -
--

\i $$PATH$$/3382.dat

--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- Name: rules rules_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rules
    ADD CONSTRAINT rules_pkey PRIMARY KEY (id);


--
-- Name: users uk_6dotkott2kjsp8vw4d0m25fb7; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT uk_6dotkott2kjsp8vw4d0m25fb7 UNIQUE (email);


--
-- Name: users_details users_details_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users_details
    ADD CONSTRAINT users_details_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: roles_rules fka0r94m9h7nmvajp1crbv3y47f; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles_rules
    ADD CONSTRAINT fka0r94m9h7nmvajp1crbv3y47f FOREIGN KEY (role_id) REFERENCES public.roles(id);


--
-- Name: users fka64wa8dgo929wep5ff2ufkqe9; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT fka64wa8dgo929wep5ff2ufkqe9 FOREIGN KEY (user_detail_id) REFERENCES public.users_details(id);


--
-- Name: roles_rules fkfwkrmegkj61d8elqngejm3hh9; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.roles_rules
    ADD CONSTRAINT fkfwkrmegkj61d8elqngejm3hh9 FOREIGN KEY (rule_id) REFERENCES public.rules(id);


--
-- Name: users fkp56c1712k691lhsyewcssf40f; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT fkp56c1712k691lhsyewcssf40f FOREIGN KEY (role_id) REFERENCES public.roles(id);


--
-- PostgreSQL database dump complete
--

